//
//  ViewController.swift
//  Task
//
//  Created by Danish Khan on 06/04/21.
//

import UIKit
import Photos
import OpalImagePicker


class CategoriesViewController: UIViewController {


    //MARK: - Outlets
    @IBOutlet private weak var dropDownLabel: UILabel!
    @IBOutlet private weak var nameTextField: UITextField!
    @IBOutlet private weak var descriptionTextView: UITextView!
    @IBOutlet private weak var datePickerTextField: UITextField!
    @IBOutlet private weak var collectionView: UICollectionView!

    
    //MARK: - Variables
    private let dropDown = MakeDropDown()
    private var categoriesViewModel:CategoriesViewModel!
    private var categories = [Categories]()
    private var dropDownRowHeight: CGFloat = 50
    private var selectedImage = [UIImage]()

    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        categoriesViewModel = CategoriesViewModel(withDelegate: self)
        datePickerTextField.addInputViewDatePicker(target: self, selector: #selector(doneButtonPressed))
        categoriesViewModel.fetchCategories(apiUrl: "http://dev1.xicom.us/xttest/get_categories.php", method: .get, header: [:])
        setUpGestures()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //Call this in viewDidAppear to get correct frame values
        setUpDropDown()
    }
    
    @objc func doneButtonPressed() {
        if let  datePicker = self.datePickerTextField.inputView as? UIDatePicker {
            datePicker.preferredDatePickerStyle = .wheels
            datePicker.sizeToFit()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy/MM/dd"
            self.datePickerTextField.text = dateFormatter.string(from: datePicker.date)
            categoriesViewModel.expiryDate = datePicker.date.getFormattedDate(format: "yyyy/MM/dd HH:mm:ss")
        }
        self.datePickerTextField.resignFirstResponder()
    }
    
    private func setUpGestures(){
        self.dropDownLabel.isUserInteractionEnabled = true
        let testLabelTapGesture = UITapGestureRecognizer(target: self, action: #selector(testLabelTapped))
        self.dropDownLabel.addGestureRecognizer(testLabelTapGesture)
    }
    
    private func setUpDropDown(){
        dropDown.makeDropDownIdentifier = "DROP_DOWN_NEW"
        dropDown.cellReusableIdentifier = "dropDownCell"
        dropDown.makeDropDownDataSourceProtocol = self
        dropDown.setUpDropDown(viewPositionReference: (dropDownLabel.frame), offset: 2)
        dropDown.nib = UINib(nibName: "DropDownTableViewCell", bundle: nil)
        dropDown.setRowHeight(height: self.dropDownRowHeight)
        self.view.addSubview(dropDown)
    }


    //MARK: - Selector Methods
    @objc func testLabelTapped(){
        // Give height to drop down according to requirement
        // In this it will show number of categories count rows in dropdown as per calculations
        self.dropDown.showDropDown(height: self.dropDownRowHeight * CGFloat(categories.count))
    }
    
    /*
     Data Validations
     */
    private func isDataValid(categoriesViewModel:CategoriesViewModel) -> Bool  {
        self.view.endEditing(true)
        var isValid = true
        var validationMessage = ""
        if let emptyMessage = categoriesViewModel.isEmptyField() {
            validationMessage = emptyMessage
            isValid = false
        }
        if !isValid {
            AlertUtility.showAlert(self, title: "Alert",message: validationMessage)
        }
        return isValid
    }
    
    @IBAction private func saveButtonTapped(_ sender: UIButton) {
        if !isDataValid(categoriesViewModel: categoriesViewModel){return}
        categoriesViewModel.addCategoryWebservice(categoryImage: self.selectedImage)
    }
    
    @IBAction private func addImagesButtonTapped(_ sender:UIButton) {
        let imagePicker = OpalImagePickerController()
        imagePicker.imagePickerDelegate = self
        present(imagePicker, animated: true, completion: nil)
    }
}

//MARK:- OpalImagePickerControllerDelegate
extension CategoriesViewController: OpalImagePickerControllerDelegate {
    func imagePicker(_ picker: OpalImagePickerController, didFinishPickingAssets assets: [PHAsset]){

        /*
         Convert selected assets to UIImage
         */
        for i in 0..<(assets.count){
            let image = getAssetThumbnail(asset: assets[i], size: CGFloat(45))
            self.selectedImage.append(image)
        }
        collectionView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerDidCancel(_ picker: OpalImagePickerController){
        dismiss(animated: true, completion: nil)
    }

}

//MARK:- UITextFieldDelegate
extension CategoriesViewController: UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        let trimedText = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if nameTextField == textField {
            categoriesViewModel?.name = trimedText!
        }
        textField.text = trimedText //set trimmed text to text field
    }
}

//MARK:- UITextViewDelegate
extension CategoriesViewController: UITextViewDelegate {
    func textViewDidEndEditing(_ textView: UITextView) {
        categoriesViewModel.descriptions = textView.text
    }
}

//MARK: - CategoriesViewModelDelegate
extension CategoriesViewController: CategoriesViewModelDelegate{
    func productUploadSucess() {
        AlertUtility.showAlert(self, title: "Success", message: "Product has been saved successfully.")
    }
    
    func productUpload(error: String) {
        AlertUtility.showAlert(self, title: "Alert", message: "Getting error.")
    }
    
    func apiFinishWithSucess() {
        /*
         Updated categories Data
         */
        categories = categoriesViewModel?.getCategories() ?? []
        print(categories)
     
    }
    
    func errorInFetchingCategories(error: String) {
        AlertUtility.showAlert(self, title: "Alert", message: error)
    }
}

//MARK: - MakeDropDownDataSourceProtocol
extension CategoriesViewController: MakeDropDownDataSourceProtocol{
    func getDataToDropDown(cell: UITableViewCell, indexPos: Int, makeDropDownIdentifier: String) {
        if makeDropDownIdentifier == "DROP_DOWN_NEW"{
            let customCell = cell as! DropDownTableViewCell
            customCell.countryNameLabel.text = self.categories[indexPos].name
            print(self.categories[indexPos].name)
        }
    }
    
    func numberOfRows(makeDropDownIdentifier: String) -> Int {
        return self.categories.count
    }
    
    func selectItemInDropDown(indexPos: Int, makeDropDownIdentifier: String) {
        self.dropDownLabel.text = self.categories[indexPos].name
        categoriesViewModel.selectedCategory = self.categories[indexPos].name
        categoriesViewModel.categoryId = self.categories[indexPos].id
        self.dropDown.hideDropDown()
    }
    
}

// MARK: - UICollectionViewDataSource
extension CategoriesViewController: UICollectionViewDataSource {
    
    // Return elements count that must be displayed in table
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedImage.count
    }
    
    // Instantiate or reused (depend on position and cell type in table view), configure cell element and return it for displaying on table
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = selectedImage[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ImageCollectionViewCell.identifier, for: indexPath) as! ImageCollectionViewCell
        cell.images.image = item
        return cell
    }
    
}


func getAssetThumbnail(asset: PHAsset, size: CGFloat) -> UIImage {
        let retinaScale = UIScreen.main.scale
        let retinaSquare = CGSize(width: size * retinaScale, height: size * retinaScale)
        let cropSizeLength = min(asset.pixelWidth, asset.pixelHeight)
        let square = CGRect(x: 0, y: 0, width: CGFloat(cropSizeLength), height: CGFloat(cropSizeLength))
        let cropRect = square.applying(CGAffineTransform(scaleX: 1.0/CGFloat(asset.pixelWidth), y: 1.0/CGFloat(asset.pixelHeight)))
        
        let manager = PHImageManager.default()
        let options = PHImageRequestOptions()
        var thumbnail = UIImage()
        
        options.isSynchronous = true
        options.deliveryMode = .highQualityFormat
        options.resizeMode = .exact
        
        options.normalizedCropRect = cropRect
        
        manager.requestImage(for: asset, targetSize: retinaSquare, contentMode: .aspectFit, options: options, resultHandler: {(result, info)->Void in
            thumbnail = result!
        })
        return thumbnail
    }


extension Date {
   func getFormattedDate(format: String) -> String {
        let dateformat = DateFormatter()
        dateformat.dateFormat = format
        return dateformat.string(from: self)
    }
}
