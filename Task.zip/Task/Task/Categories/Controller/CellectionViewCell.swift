//
//  CellectionViewCell.swift
//  Task
//
//  Created by Danish Khan on 06/04/21.
//

import Foundation
import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var images: UIImageView!
    
    class var identifier: String { return "ImageCollectionViewCell" }
    
}
