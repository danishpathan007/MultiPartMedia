//
//  Categories.swift
//  Task
//
//  Created by Danish Khan on 06/04/21.
//

import Foundation
import ObjectMapper

class Categories: Mappable {
    
    
    var id : String?
    var name : String?
    
    init() {}
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        id    <-    map["id"]
        name   <-    map["name"]
    }
}
