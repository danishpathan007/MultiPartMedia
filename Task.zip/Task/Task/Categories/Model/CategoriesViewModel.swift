//
//  CategoriesViewModel.swift
//  Task
//
//  Created by Danish Khan on 06/04/21.
//

import Foundation
import Alamofire
import ObjectMapper

protocol CategoriesViewModelDelegate: class {
    func apiFinishWithSucess()
    func errorInFetchingCategories(error: String)
    func productUploadSucess()
    func productUpload(error:String)
}

class CategoriesViewModel:NSObject {
    
    weak var delegate: CategoriesViewModelDelegate?
    var categories = [Categories]()
    var selectedCategory:String?
    var expiryDate:String?
    var name:String?
    var descriptions: String?
    var images:[UIImage]?
    var categoryId:String?
    

    init(withDelegate delegate: CategoriesViewModelDelegate) {
        super.init()
        self.delegate = delegate
    }
    
    init(name:String?,descriptions:String?,images:[UIImage]?,selectedCategory:String?,expiryDate:String?,categoryId:String?) {
        self.name = name
        self.descriptions = descriptions
        self.images = images
        self.selectedCategory = selectedCategory
        self.expiryDate = expiryDate
        self.categoryId = categoryId
    }
    
    func getCategories() -> [Categories] {
        return categories
    }
    
    
    func isEmptyField() -> String? {
        
        guard  let selectedCategory = selectedCategory else { return Constants.ValidationMessages.category
        }
        if selectedCategory.trimSpace().isEmpty {
            return Constants.ValidationMessages.category
        }
        
        guard  let name = name else { return Constants.ValidationMessages.name.empty
        }
        if name.trimSpace().isEmpty {
            return Constants.ValidationMessages.name.empty
        }
        
        guard  let descriptions = descriptions else { return Constants.ValidationMessages.description
        }
        if descriptions.trimSpace().isEmpty {
            return Constants.ValidationMessages.description
        }
        
        guard  let expiryDate = expiryDate else { return Constants.ValidationMessages.expiryDate
        }
        if expiryDate.trimSpace().isEmpty {
            return Constants.ValidationMessages.expiryDate
        }
       
        return nil
    }
    

    /*
     Fetch Categories
     */
    func fetchCategories(apiUrl: String, method: HTTPMethod,header: [String:Any]) {
        
        let parameters:[String:Any] = [:]
        
        Alamofire.request(apiUrl, method: method, parameters: parameters, encoding: URLEncoding.default, headers: header as? HTTPHeaders).responseJSON { respons in
            if respons.result.error == nil {
                if let JSON = respons.result.value as? [String:Any] {
                    self.parseData(json: JSON)
                }
            }else{
                self.delegate?.errorInFetchingCategories(error: "Error")
            }
        }
    }
    
    /*
     Helper Method
     */
    private func parseData(json:[String:Any]) {
        if let categories = json["categories"] as? [[String:Any]] {
            print(categories)
            let categories = Mapper<Categories>().mapArray(JSONArray: categories)
            self.categories = categories
            self.delegate?.apiFinishWithSucess()
        }
    }
    
    //MARK:- Api Functions
    func addCategoryWebservice(categoryImage:[UIImage]){
        var imageData = [Data]()
        let count = categoryImage.count

        for i in 0..<count{
            imageData.append(categoryImage[i].jpegData(compressionQuality: 0.75)!)
        }
        let parameters:[String : String] = [
            "category_id" : categoryId ?? "",
            "name" : name ?? "",
            "desc" : descriptions ?? "",
            "expiry" : expiryDate ?? ""
        ]
        
        print(parameters)
        
        MultiPartImageUpload.multipartRequestWith(url: "http://dev1.xicom.us/xttest/save_user.php", imageData: imageData, parameters: parameters, onCompletion: { (json) in
            self.delegate?.productUploadSucess()
        }) { (error) in
            self.delegate?.productUpload(error: error!.localizedDescription)
        }
   }
}


class MultiPartImageUpload{
    class func multipartRequestWith(url: String, imageData: [Data]?, parameters: [String : String], onCompletion: (([String: Any]?) -> Void)? = nil, onError: ((Error?) -> Void)? = nil){

        let headers: HTTPHeaders = [:]
        
    Alamofire.upload(multipartFormData: { (multipartFormData) in
            for (key, value) in parameters {
                multipartFormData.append(value.data(using: .utf8)!, withName: key)
            }
       
        if imageData != nil{
            for i in 0..<(imageData?.count)!{
                multipartFormData.append(imageData![i], withName: "product_image[\(i)]", fileName: "photo\(i).jpeg", mimeType: "image/jpeg")
            }
        }
        
        }, usingThreshold: UInt64.init(), to: url, method: .post, headers: headers) { (result) in
            switch result{
            case .success(let upload, _, _):
                upload.uploadProgress(closure: { (progress) in
                 print(progress)
                })
                upload.responseJSON { response in
                    if let err = response.error{
                        onError?(err)
                        return
                    }
                    let json = response.result.value as? [String: Any]
                    print(json)
                    onCompletion?(json)
                }
            case .failure(let error):
                onError?(error)
            }
        }
    }
}
